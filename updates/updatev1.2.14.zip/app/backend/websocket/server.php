<?php

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use React\EventLoop\Factory as LoopFactory;
use React\Socket\Connector;
use Ratchet\Client\Connector as WsConnector;

require dirname(__DIR__) . '/vendor/autoload.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../core/jwt_utils.php';
require_once __DIR__ . '/../core/response.php';
require_once __DIR__ . '/../utility/Logger.php';
require_once __DIR__ . '/../services/ProfitCalculationService.php';
require_once __DIR__ . '/../services/TradeMonitorService.php';
require_once __DIR__ . '/../services/TradeAlterMonitorService.php';
require_once __DIR__ . '/../services/TradeService.php';
require_once __DIR__ . '/../services/WebSocketNotificationQueue.php';
require_once __DIR__ . '/../services/AlteredCandleCacheService.php';
require_once __DIR__ . '/../services/PriceFormatterService.php';
require_once __DIR__ . '/../services/PendingTradeMonitorService.php';
require_once __DIR__ . '/../services/PlatformService.php';
require_once __DIR__ . '/FinnhubWebSocketClient.php';

// Disable exit() in Response class for WebSocket server context
Response::disableExit();

class TradingWebSocketServer implements MessageComponentInterface {
    protected $clients;
    protected $authenticatedClients; // Map of userId => [connections]
    protected $binanceConnection;
    protected $currentPrices;
    protected $alteredPrices; // Map of alter-affected trades/pairs => altered prices
    protected $chartAlters; // Active chart alters for synthetic candle generation
    protected $subscribedPairs;
    protected $chartSubscriptions; // Map of resourceId => ['pair' => 'interval']
    protected $adminAccountSubscriptions; // Map of resourceId => [accountIds]
    protected $adminTradeSubscriptions; // Map of resourceId => [tradeIds]
    protected $formingCandles; // Track forming candles with high/low updates
    protected $currentMarketStatus; // Current market status: 'open', 'closed', or 'unknown'
    protected $currentMarketData; // Full market data for forex and stocks
    
    public function __construct() {
        $this->clients = new \SplObjectStorage;
        $this->authenticatedClients = [];
        $this->currentPrices = [];
        $this->alteredPrices = []; // Initialize altered prices storage
        $this->chartAlters = []; // Initialize chart alters storage
        $this->subscribedPairs = [];
        $this->chartSubscriptions = []; // Initialize chart subscriptions storage
        $this->adminAccountSubscriptions = []; // Initialize admin account subscriptions
        $this->adminTradeSubscriptions = []; // Initialize admin trade subscriptions
        $this->formingCandles = []; // Initialize forming candles tracker
        $this->currentMarketStatus = 'unknown'; // Will be determined after Finnhub connects
        $this->currentMarketData = null; // Will be set when market status is first broadcast
        
        // Load cached prices from file to prevent stale data on restart
        $this->loadCachedPrices();
        
        // Set up WebSocket notification callback for trade closures
        // This allows TradeService to notify WebSocket clients when trades are closed
        TradeService::setNotificationCallback(function($trade, $reason) {
            $this->notifyTradeClosed($trade);
        });
        
        // Set up WebSocket notification callback for pending order triggers
        // This allows PendingTradeMonitorService to notify when orders are executed
        PendingTradeMonitorService::setNotificationCallback(function($order, $tradeData) {
            $this->notifyOrderTriggered($order, $tradeData);
        });
        
        Logger::init('websocket-server.log');
        Logger::info("WebSocket Server initialized");
        Logger::info("Trade closure notifications enabled (SL/TP/Margin/Alter/Admin)");
        Logger::info("Pending order trigger notifications enabled");
        Logger::info("Chart alteration system enabled");
    }
    
    /**
     * Load cached prices from file on server startup
     * This prevents showing stale/empty data until Binance sends first update
     */
    private function loadCachedPrices() {
        $cacheFile = __DIR__ . '/../cache/websocket_live_prices.json';
        
        if (!file_exists($cacheFile)) {
            Logger::info("[CACHE] No cached prices found - starting with empty prices");
            return;
        }
        
        $cacheContent = file_get_contents($cacheFile);
        $cacheData = json_decode($cacheContent, true);
        
        if (!$cacheData || !isset($cacheData['prices'])) {
            Logger::info("[CACHE] Invalid cache format - starting with empty prices");
            return;
        }
        
        // Load prices into memory
        $this->currentPrices = $cacheData['prices'];
        $priceCount = count($this->currentPrices);
        $cacheAge = isset($cacheData['timestamp']) ? (time() - $cacheData['timestamp']) : 'unknown';
        
        Logger::info("[CACHE] ✅ Loaded $priceCount cached prices into memory");
        Logger::info("[CACHE] Cache age: $cacheAge seconds");
        
        // List first 5 prices for debugging
        $samplePrices = array_slice($this->currentPrices, 0, 5, true);
        foreach ($samplePrices as $pair => $price) {
            Logger::info("[CACHE]   $pair = $price");
        }
    }
    
    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        $conn->userId = null;
        Logger::info("New connection: {$conn->resourceId}");
    }
    
    public function onMessage(ConnectionInterface $from, $msg) {
        try {
            $data = json_decode($msg, true);
            
            if (!$data || !isset($data['type'])) {
                $from->send(json_encode(['error' => 'Invalid message format']));
                return;
            }
            
            // Log all message types
            Logger::info("[MSG] Client {$from->resourceId} sent type: {$data['type']}");
            
            switch ($data['type']) {
                case 'auth':
                    $this->handleAuth($from, $data);
                    break;
                    
                case 'subscribe_prices':
                    $this->handleSubscribePrices($from, $data);
                    break;
                    
                case 'unsubscribe_prices':
                    $this->handleUnsubscribePrices($from, $data);
                    break;
                    
                case 'subscribe_trades':
                    $this->handleSubscribeTrades($from, $data);
                    break;
                    
                case 'subscribe_chart':
                    Logger::info("[MSG] Processing subscribe_chart for client {$from->resourceId}");
                    $this->handleSubscribeChart($from, $data);
                    break;
                    
                case 'unsubscribe_chart':
                    $this->handleUnsubscribeChart($from, $data);
                    break;
                    
                case 'subscribe_account':
                    // Admin: subscribe to any account's data
                    $this->handleAdminSubscribeAccount($from, $data);
                    break;
                    
                case 'unsubscribe_account':
                    // Admin: unsubscribe from account
                    $this->handleAdminUnsubscribeAccount($from, $data);
                    break;
                    
                case 'subscribe_trade':
                    // Admin: subscribe to any trade's live P&L
                    $this->handleAdminSubscribeTrade($from, $data);
                    break;
                    
                case 'unsubscribe_trade':
                    // Admin: unsubscribe from trade
                    $this->handleAdminUnsubscribeTrade($from, $data);
                    break;
                    
                case 'get_account':
                    $this->handleGetAccount($from);
                    break;
                    
                case 'ping':
                    $from->send(json_encode(['type' => 'pong']));
                    break;
                    
                default:
                    $from->send(json_encode(['error' => 'Unknown message type']));
            }
        } catch (Exception $e) {
            error_log("WebSocket message error: " . $e->getMessage());
            $from->send(json_encode(['error' => 'Server error']));
        }
    }
    
    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        
        // Clean up chart subscriptions
        if (isset($this->chartSubscriptions[$conn->resourceId])) {
            unset($this->chartSubscriptions[$conn->resourceId]);
            Logger::info("Cleaned up chart subscriptions for client {$conn->resourceId}");
        }
        
        // Clean up admin account subscriptions
        if (isset($this->adminAccountSubscriptions[$conn->resourceId])) {
            unset($this->adminAccountSubscriptions[$conn->resourceId]);
            Logger::info("Cleaned up admin account subscriptions for client {$conn->resourceId}");
        }
        
        // Clean up admin trade subscriptions
        if (isset($this->adminTradeSubscriptions[$conn->resourceId])) {
            unset($this->adminTradeSubscriptions[$conn->resourceId]);
            Logger::info("Cleaned up admin trade subscriptions for client {$conn->resourceId}");
        }
        
        if ($conn->userId) {
            // Remove from authenticated clients
            if (isset($this->authenticatedClients[$conn->userId])) {
                $key = array_search($conn, $this->authenticatedClients[$conn->userId], true);
                if ($key !== false) {
                    unset($this->authenticatedClients[$conn->userId][$key]);
                }
                
                if (empty($this->authenticatedClients[$conn->userId])) {
                    unset($this->authenticatedClients[$conn->userId]);
                }
            }
        }
        
        Logger::info("Connection {$conn->resourceId} disconnected");
    }
    
    public function onError(ConnectionInterface $conn, \Exception $e) {
        error_log("WebSocket error: " . $e->getMessage());
        $conn->close();
    }
    
    private function handleAuth(ConnectionInterface $conn, $data) {
        if (!isset($data['token'])) {
            $conn->send(json_encode(['type' => 'auth_error', 'message' => 'Token required']));
            return;
        }
        
        try {
            // Verify JWT token
            $decoded = verify_jwt($data['token'], 'base');
            
            if ($decoded && isset($decoded->user_id)) {
                $userId = $decoded->user_id;
                $conn->userId = $userId;
                
                // Get user role from database
                $dbConn = Database::getConnection();
                $stmt = $dbConn->prepare("SELECT role FROM users WHERE id = ?");
                $stmt->bind_param("i", $userId);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $user = $result->fetch_assoc();
                    $conn->userRole = $user['role'];
                } else {
                    $conn->userRole = 'user'; // Default to user if not found
                }
                
                // Add to authenticated clients
                if (!isset($this->authenticatedClients[$userId])) {
                    $this->authenticatedClients[$userId] = [];
                }
                $this->authenticatedClients[$userId][] = $conn;
                
                $conn->send(json_encode([
                    'type' => 'auth_success',
                    'userId' => $userId,
                    'role' => $conn->userRole
                ]));
                
                Logger::info("User {$userId} authenticated (Role: {$conn->userRole})");
                
                // Send current market status to newly authenticated client
                $this->sendCurrentMarketStatus($conn);
                
                // Only send initial account data to regular users (not admins/superadmins)
                if ($conn->userRole === 'user') {
                    $this->sendAccountUpdate($userId);
                }
            } else {
                $conn->send(json_encode(['type' => 'auth_error', 'message' => 'Invalid token']));
            }
        } catch (Exception $e) {
            $conn->send(json_encode(['type' => 'auth_error', 'message' => 'Authentication failed']));
        }
    }
    
    private function handleSubscribePrices(ConnectionInterface $conn, $data) {
        if (!$conn->userId) {
            $conn->send(json_encode(['error' => 'Not authenticated']));
            return;
        }
        
        if (!isset($data['pairs']) || !is_array($data['pairs'])) {
            $conn->send(json_encode(['error' => 'Invalid pairs']));
            return;
        }
        
        // Initialize if not exists
        if (!isset($conn->subscribedPairs)) {
            $conn->subscribedPairs = [];
        }
        
        // Add new pairs to existing subscriptions (merge without duplicates)
        $conn->subscribedPairs = array_unique(array_merge($conn->subscribedPairs, $data['pairs']));
        
        $conn->send(json_encode([
            'type' => 'prices_subscribed',
            'pairs' => $data['pairs'],
            'total_subscribed' => count($conn->subscribedPairs)
        ]));
        
        echo "Client {$conn->resourceId} subscribed to " . count($data['pairs']) . " price pair(s)\n";
    }
    
    private function handleUnsubscribePrices(ConnectionInterface $conn, $data) {
        if (!$conn->userId) {
            $conn->send(json_encode(['error' => 'Not authenticated']));
            return;
        }
        
        if (!isset($data['pairs']) || !is_array($data['pairs'])) {
            $conn->send(json_encode(['error' => 'Invalid pairs']));
            return;
        }
        
        if (!isset($conn->subscribedPairs)) {
            $conn->subscribedPairs = [];
        }
        
        // Remove specified pairs from subscriptions
        $conn->subscribedPairs = array_values(array_diff($conn->subscribedPairs, $data['pairs']));
        
        $conn->send(json_encode([
            'type' => 'prices_unsubscribed',
            'pairs' => $data['pairs'],
            'total_subscribed' => count($conn->subscribedPairs)
        ]));
        
        echo "Client {$conn->resourceId} unsubscribed from " . count($data['pairs']) . " price pair(s)\n";
    }
    
    private function handleSubscribeTrades(ConnectionInterface $conn, $data) {
        if (!$conn->userId) {
            $conn->send(json_encode(['error' => 'Not authenticated']));
            return;
        }
        
        // Enable trade subscription
        $conn->tradesSubscribed = true;
        
        // Determine which trade pairs to subscribe to
        if (!isset($data['pairs'])) {
            // No pairs specified = all trades
            $conn->subscribedTradePairs = null;
        } elseif ($data['pairs'] === 'all' || $data['pairs'] === '*') {
            // Explicitly request all trades
            $conn->subscribedTradePairs = null;
        } elseif (is_array($data['pairs']) && count($data['pairs']) > 0) {
            // Specific pairs only
            $conn->subscribedTradePairs = $data['pairs'];
        } else {
            // Invalid format, default to all
            $conn->subscribedTradePairs = null;
        }
        
        $conn->send(json_encode([
            'type' => 'trades_subscribed',
            'pairs' => $conn->subscribedTradePairs === null ? 'all' : $conn->subscribedTradePairs
        ]));
        
        // Send initial trades data
        $this->sendAccountUpdate($conn->userId);
    }
    
    private function handleGetAccount(ConnectionInterface $conn) {
        if (!$conn->userId) {
            $conn->send(json_encode(['error' => 'Not authenticated']));
            return;
        }
        
        $this->sendAccountUpdate($conn->userId);
    }
    
    private function handleSubscribeChart(ConnectionInterface $conn, $data) {
        if (!isset($data['pair']) || !isset($data['interval'])) {
            $conn->send(json_encode(['error' => 'Pair and interval required']));
            return;
        }
        
        $pair = $data['pair'];
        $interval = $data['interval'];
        
        Logger::info("[SUBSCRIBE_CHART] Client {$conn->resourceId} requesting: pair='{$pair}', interval='{$interval}'");
        echo "[SUBSCRIBE_CHART] Current chartSubscriptions count: " . count($this->chartSubscriptions) . "\n";
        
        // Store subscription in server-level array instead of connection property
        $resourceId = $conn->resourceId;
        
        if (!isset($this->chartSubscriptions[$resourceId])) {
            $this->chartSubscriptions[$resourceId] = [];
        }
        
        // Add to subscriptions
        $this->chartSubscriptions[$resourceId][$pair] = $interval;
        
        Logger::info("[SUBSCRIBE_CHART] ✓ Stored subscription: chartSubscriptions[{$resourceId}]['{$pair}'] = '{$interval}'");
        echo "[SUBSCRIBE_CHART] Total subscriptions for this client: " . count($this->chartSubscriptions[$resourceId]) . "\n";
        
        $conn->send(json_encode([
            'type' => 'chart_subscribed',
            'pair' => $pair,
            'interval' => $interval,
            'message' => "Subscribed to {$pair} {$interval} candles"
        ]));
        
        Logger::info("Client {$conn->resourceId} subscribed to {$pair} chart ({$interval})");
    }
    
    private function handleUnsubscribeChart(ConnectionInterface $conn, $data) {
        if (!isset($data['pair'])) {
            $conn->send(json_encode(['error' => 'Pair required']));
            return;
        }
        
        $pair = $data['pair'];
        $resourceId = $conn->resourceId;
        
        if (isset($this->chartSubscriptions[$resourceId][$pair])) {
            unset($this->chartSubscriptions[$resourceId][$pair]);
            
            $conn->send(json_encode([
                'type' => 'chart_unsubscribed',
                'pair' => $pair
            ]));
            
            Logger::info("Client {$conn->resourceId} unsubscribed from {$pair} chart");
        }
    }
    
    private function checkAdminPermission(ConnectionInterface $conn, $requiredPermissions) {
        if (!$conn->userId) {
            return ['allowed' => false, 'error' => 'Not authenticated'];
        }
        
        try {
            // Get user from database
            $dbConn = Database::getConnection();
            $stmt = $dbConn->prepare("SELECT role, permissions FROM users WHERE id = ?");
            $stmt->bind_param("i", $conn->userId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                return ['allowed' => false, 'error' => 'User not found'];
            }
            
            $user = $result->fetch_assoc();
            $role = $user['role'];
            
            // Superadmin has all permissions
            if ($role === 'superadmin') {
                return ['allowed' => true, 'role' => 'superadmin'];
            }
            
            // Admin must have specific permissions
            if ($role === 'admin') {
                $userPermissions = json_decode($user['permissions'], true) ?? [];
                
                // Check if user has any of the required permissions
                foreach ($requiredPermissions as $permission) {
                    if (in_array($permission, $userPermissions)) {
                        return ['allowed' => true, 'role' => 'admin', 'permissions' => $userPermissions];
                    }
                }
                
                return ['allowed' => false, 'error' => 'Insufficient permissions. Required: ' . implode(' or ', $requiredPermissions)];
            }
            
            return ['allowed' => false, 'error' => 'Access denied. Admin role required.'];
        } catch (Exception $e) {
            error_log("Permission check error: " . $e->getMessage());
            return ['allowed' => false, 'error' => 'Permission check failed'];
        }
    }
    
    private function handleAdminSubscribeAccount(ConnectionInterface $conn, $data) {
        // Check permission: manage_accounts OR manage_trades
        $permCheck = $this->checkAdminPermission($conn, ['manage_accounts', 'manage_trades']);
        
        if (!$permCheck['allowed']) {
            $conn->send(json_encode(['type' => 'error', 'message' => $permCheck['error']]));
            return;
        }
        
        if (!isset($data['account_id'])) {
            $conn->send(json_encode(['type' => 'error', 'message' => 'account_id required']));
            return;
        }
        
        $accountId = $data['account_id'];
        $resourceId = $conn->resourceId;
        
        // Verify account exists
        try {
            $dbConn = Database::getConnection();
            $stmt = $dbConn->prepare("SELECT id_hash, balance FROM accounts WHERE id_hash = ?");
            $stmt->bind_param("s", $accountId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                $conn->send(json_encode(['type' => 'error', 'message' => 'Account not found']));
                return;
            }
            
            // Initialize subscription storage
            if (!isset($this->adminAccountSubscriptions[$resourceId])) {
                $this->adminAccountSubscriptions[$resourceId] = [];
            }
            
            // Add subscription
            $this->adminAccountSubscriptions[$resourceId][] = $accountId;
            
            $conn->send(json_encode([
                'type' => 'account_subscribed',
                'account_id' => $accountId,
                'message' => "Subscribed to account {$accountId}"
            ]));
            
            Logger::info("[ADMIN] Client {$resourceId} ({$permCheck['role']}) subscribed to account {$accountId}");
            
            // Send initial account data
            $this->sendAdminAccountUpdate($accountId);
            
        } catch (Exception $e) {
            error_log("Admin subscribe account error: " . $e->getMessage());
            $conn->send(json_encode(['type' => 'error', 'message' => 'Failed to subscribe to account']));
        }
    }
    
    private function handleAdminUnsubscribeAccount(ConnectionInterface $conn, $data) {
        if (!isset($data['account_id'])) {
            $conn->send(json_encode(['type' => 'error', 'message' => 'account_id required']));
            return;
        }
        
        $accountId = $data['account_id'];
        $resourceId = $conn->resourceId;
        
        if (isset($this->adminAccountSubscriptions[$resourceId])) {
            $key = array_search($accountId, $this->adminAccountSubscriptions[$resourceId]);
            if ($key !== false) {
                unset($this->adminAccountSubscriptions[$resourceId][$key]);
                $conn->send(json_encode([
                    'type' => 'account_unsubscribed',
                    'account_id' => $accountId
                ]));
                Logger::info("[ADMIN] Client {$resourceId} unsubscribed from account {$accountId}");
            }
        }
    }
    
    private function handleAdminSubscribeTrade(ConnectionInterface $conn, $data) {
        // Check permission: manage_trades
        $permCheck = $this->checkAdminPermission($conn, ['manage_trades']);
        
        if (!$permCheck['allowed']) {
            $conn->send(json_encode(['type' => 'error', 'message' => $permCheck['error']]));
            return;
        }
        
        if (!isset($data['trade_id'])) {
            $conn->send(json_encode(['type' => 'error', 'message' => 'trade_id required']));
            return;
        }
        
        $tradeId = $data['trade_id'];
        $resourceId = $conn->resourceId;
        
        // Verify trade exists and is open
        try {
            $dbConn = Database::getConnection();
            $stmt = $dbConn->prepare("
                SELECT t.*, p.lot_size, p.digits 
                FROM trades t 
                LEFT JOIN pairs p ON t.pair = p.name 
                WHERE t.id = ? AND (t.close_date IS NULL OR t.close_date = '')
            ");
            $stmt->bind_param("i", $tradeId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                $conn->send(json_encode(['type' => 'error', 'message' => 'Open trade not found']));
                return;
            }
            
            $trade = $result->fetch_assoc();
            
            // Initialize subscription storage
            if (!isset($this->adminTradeSubscriptions[$resourceId])) {
                $this->adminTradeSubscriptions[$resourceId] = [];
            }
            
            // Add subscription
            $this->adminTradeSubscriptions[$resourceId][] = $tradeId;
            
            $conn->send(json_encode([
                'type' => 'trade_subscribed',
                'trade_id' => $tradeId,
                'pair' => $trade['pair'],
                'type' => $trade['type'],
                'message' => "Subscribed to trade #{$tradeId}"
            ]));
            
            Logger::info("[ADMIN] Client {$resourceId} ({$permCheck['role']}) subscribed to trade {$tradeId}");
            echo "[DEBUG] adminTradeSubscriptions now: " . json_encode($this->adminTradeSubscriptions) . "\n";
            
            // Send initial trade data
            $this->sendAdminTradeUpdate($tradeId);
            
        } catch (Exception $e) {
            error_log("Admin subscribe trade error: " . $e->getMessage());
            $conn->send(json_encode(['type' => 'error', 'message' => 'Failed to subscribe to trade']));
        }
    }
    
    private function handleAdminUnsubscribeTrade(ConnectionInterface $conn, $data) {
        if (!isset($data['trade_id'])) {
            $conn->send(json_encode(['type' => 'error', 'message' => 'trade_id required']));
            return;
        }
        
        $tradeId = $data['trade_id'];
        $resourceId = $conn->resourceId;
        
        if (isset($this->adminTradeSubscriptions[$resourceId])) {
            $key = array_search($tradeId, $this->adminTradeSubscriptions[$resourceId]);
            if ($key !== false) {
                unset($this->adminTradeSubscriptions[$resourceId][$key]);
                $conn->send(json_encode([
                    'type' => 'trade_unsubscribed',
                    'trade_id' => $tradeId
                ]));
                Logger::info("[ADMIN] Client {$resourceId} unsubscribed from trade {$tradeId}");
            }
        }
    }
    
    private function sendAdminAccountUpdate($accountId) {
        // Calculate account balances with current prices
        $balances = ProfitCalculationService::calculateAccountBalances($accountId, $this->currentPrices);
        
        if (!$balances) {
            return;
        }
        
        // Send to all clients subscribed to this account
        foreach ($this->adminAccountSubscriptions as $resourceId => $accountIds) {
            if (in_array($accountId, $accountIds)) {
                // Find the connection with this resourceId
                foreach ($this->clients as $conn) {
                    if ($conn->resourceId === $resourceId) {
                        $conn->send(json_encode([
                            'type' => 'admin_account_update',
                            'account_id' => $accountId,
                            'data' => [
                                'balance' => $balances['balance'],
                                'equity' => $balances['equity'],
                                'freeMargin' => $balances['freeMargin'],
                                'totalMargin' => $balances['totalMargin'],
                                'profit_loss' => $balances['profit_loss'],
                                'formattedProfit_loss' => $balances['formattedProfit_loss']
                            ],
                            'timestamp' => time()
                        ]));
                        break;
                    }
                }
            }
        }
    }
    
    private function sendAdminTradeUpdate($tradeId) {
        try {
            $dbConn = Database::getConnection();
            $stmt = $dbConn->prepare("
                SELECT t.*, p.lot_size, p.digits 
                FROM trades t 
                LEFT JOIN pairs p ON t.pair = p.name 
                WHERE t.id = ? AND (t.close_date IS NULL OR t.close_date = '')
            ");
            $stmt->bind_param("i", $tradeId);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                // Trade not found or closed - notify subscribers
                foreach ($this->adminTradeSubscriptions as $resourceId => $tradeIds) {
                    if (in_array($tradeId, $tradeIds)) {
                        foreach ($this->clients as $conn) {
                            if ($conn->resourceId === $resourceId) {
                                $conn->send(json_encode([
                                    'type' => 'admin_trade_closed',
                                    'trade_id' => $tradeId,
                                    'message' => 'Trade has been closed'
                                ]));
                                
                                // Remove subscription
                                $key = array_search($tradeId, $this->adminTradeSubscriptions[$resourceId]);
                                if ($key !== false) {
                                    unset($this->adminTradeSubscriptions[$resourceId][$key]);
                                }
                                break;
                            }
                        }
                    }
                }
                return;
            }
            
            $trade = $result->fetch_assoc();
            
            // Get current price
            $pairKey = ProfitCalculationService::getPairKey($trade['pair']);
            $currentPrice = isset($this->currentPrices[$pairKey]) ? $this->currentPrices[$pairKey] : null;
            
            $tradeData = [
                'id' => $trade['id'],
                'ref' => $trade['ref'],
                'pair' => $trade['pair'],
                'type' => $trade['type'],
                'lot' => floatval($trade['lot']),
                'leverage' => intval($trade['leverage']),
                'trade_price' => floatval($trade['trade_price']),
                'take_profit' => $trade['take_profit'],
                'stop_loss' => $trade['stop_loss'],
                'margin' => floatval($trade['margin']),
                'commission' => floatval($trade['commission']),
                'swap' => floatval($trade['swap']),
                'date' => $trade['date'],
                'account' => $trade['account']
            ];
            
            // Calculate live P&L if current price available
            if ($currentPrice !== null) {
                $pairConfig = [
                    'lot_size' => $trade['lot_size'] ?? 1,
                    'digits' => $trade['digits'] ?? 2
                ];
                
                $profitCalc = ProfitCalculationService::calculateTradeProfit($trade, $currentPrice, $pairConfig);
                if ($profitCalc) {
                    // Format currentPrice as string with correct decimals for this pair
                    $tradeData['currentPrice'] = PriceFormatterService::formatPriceString($trade['pair'], $currentPrice);
                    $tradeData['totalProfit'] = $profitCalc['totalProfit'];
                    $tradeData['formattedProfit'] = $profitCalc['formattedProfit'];
                    $tradeData['profitStatus'] = $profitCalc['profitStatus'];
                }
            } else {
                $tradeData['currentPrice'] = null;
                $tradeData['totalProfit'] = 0;
                $tradeData['formattedProfit'] = 'pending';
                $tradeData['profitStatus'] = 'pending';
            }
            
            // Send to all clients subscribed to this trade
            foreach ($this->adminTradeSubscriptions as $resourceId => $tradeIds) {
                if (in_array($tradeId, $tradeIds)) {
                    foreach ($this->clients as $conn) {
                        if ($conn->resourceId === $resourceId) {
                            $conn->send(json_encode([
                                'type' => 'admin_trade_update',
                                'trade_id' => $tradeId,
                                'data' => $tradeData,
                                'timestamp' => time()
                            ]));
                            break;
                        }
                    }
                }
            }
            
        } catch (Exception $e) {
            error_log("Admin trade update error: " . $e->getMessage());
        }
    }
    
    private function sendAccountUpdate($userId, $filterPairs = null) {
        if (!isset($this->authenticatedClients[$userId])) {
            return;
        }
        
        foreach ($this->authenticatedClients[$userId] as $conn) {
            // Only send account updates to regular users (not admins/superadmins)
            if (!isset($conn->userRole) || $conn->userRole !== 'user') {
                continue;
            }
            
            // Calculate account balances with current prices
            $balances = ProfitCalculationService::calculateCurrentAccountBalances($userId, $this->currentPrices);
            
            if ($balances) {
                $message = [
                    'type' => 'account_update',
                    'balance' => $balances['balance'],
                    'equity' => $balances['equity'],
                    'freeMargin' => $balances['freeMargin'],
                    'totalMargin' => $balances['totalMargin'],
                    'profit_loss' => $balances['profit_loss'],
                    'formattedProfit_loss' => $balances['formattedProfit_loss']
                ];
                
                // Only include trades if user is subscribed to trades
                if (isset($conn->tradesSubscribed) && $conn->tradesSubscribed === true) {
                    // Use connection-specific trade pair filter if available
                    $tradePairFilter = $filterPairs ?? $conn->subscribedTradePairs ?? null;
                    
                    // Get individual trade profits with optional filtering
                    // calculateTradeProfit will automatically apply altered prices
                    $tradeProfits = ProfitCalculationService::getOpenTradesProfits(
                        $userId, 
                        $this->currentPrices, 
                        $tradePairFilter
                    );
                    
                    $message['openTrades'] = $tradeProfits;
                    $message['tradeFilter'] = $tradePairFilter === null ? 'all' : $tradePairFilter;
                }
                
                $conn->send(json_encode($message));
            }
        }
    }
    
    private function notifyTradeClosed($closedTradeInfo) {
        // Get the user ID and trade ID from the closed trade info
        try {
            $userId = $closedTradeInfo['userid'];
            $tradeId = $closedTradeInfo['id'] ?? $closedTradeInfo['trade_id'] ?? null;
            // Handle both 'reason' (from queue) and 'close_reason' (from callback)
            $reason = $closedTradeInfo['reason'] ?? $closedTradeInfo['close_reason'] ?? 'manual';
            
            // Map reason to user-friendly message
            $reasonMessages = [
                'manual' => 'manually closed',
                'stop_loss' => 'Stop Loss triggered',
                'take_profit' => 'Take Profit triggered',
                'margin_call' => 'closed due to Margin Call',
                'stop_out' => 'closed due to Stop Out',
                'expire' => 'closed by Alter Trade completion',
                'admin' => 'closed by Admin'
            ];
            
            $message = $reasonMessages[$reason] ?? $reason;
            
            // Prepare notification message
            $notificationData = [
                'type' => 'trade_closed',
                'trade_id' => $tradeId,
                'ref' => $closedTradeInfo['ref'] ?? null,
                'pair' => $closedTradeInfo['pair'] ?? null,
                // Handle both 'type' (from callback) and 'trade_type' (from queue)
                'trade_type' => $closedTradeInfo['trade_type'] ?? $closedTradeInfo['type'] ?? null,
                'reason' => $reason,
                'profit' => $closedTradeInfo['profit'] ?? '0.00',
                'close_price' => $closedTradeInfo['close_price'] ?? null,
                'message' => $message . ' for ' . ($closedTradeInfo['pair'] ?? 'trade'),
                'timestamp' => time(),
                'user_id' => $userId // Include user_id for admin context
            ];
            
            // Send notification to the trade owner (regular user)
            if (isset($this->authenticatedClients[$userId])) {
                Logger::info("[NOTIFY] Sending trade_closed notification to user {$userId} (reason: {$reason})");
                
                foreach ($this->authenticatedClients[$userId] as $conn) {
                    $conn->send(json_encode($notificationData));
                }
                
                // Force account update to refresh balance and open trades
                $this->sendAccountUpdate($userId);
            } else {
                Logger::info("[NOTIFY] User {$userId} not connected to WebSocket");
            }
            
            // Send notification to admins subscribed to this specific trade
            if ($tradeId !== null) {
                $adminNotificationsSent = 0;
                
                Logger::info("[DEBUG] Checking admin subscriptions for trade {$tradeId}...");
                echo "[DEBUG] adminTradeSubscriptions: " . json_encode($this->adminTradeSubscriptions) . "\n";
                echo "[DEBUG] Number of admin subscription keys: " . count($this->adminTradeSubscriptions) . "\n";
                
                foreach ($this->adminTradeSubscriptions as $resourceId => $subscribedTradeIds) {
                    echo "[DEBUG] Checking resourceId {$resourceId} with subscribed trades: " . json_encode($subscribedTradeIds) . "\n";
                    
                    // Check if this admin is subscribed to this trade
                    if (in_array($tradeId, $subscribedTradeIds)) {
                        Logger::info("[DEBUG] ResourceId {$resourceId} is subscribed to trade {$tradeId}. Looking for connection...");
                        
                        // Find the admin connection
                        $foundConnection = false;
                        foreach ($this->clients as $conn) {
                            if ($conn->resourceId === $resourceId) {
                                Logger::info("[NOTIFY] Sending trade_closed notification to admin (resourceId: {$resourceId}, trade: {$tradeId})");
                                $conn->send(json_encode($notificationData));
                                $adminNotificationsSent++;
                                $foundConnection = true;
                                
                                // Also send updated trade data to admin
                                $this->sendAdminTradeUpdate($tradeId);
                                break;
                            }
                        }
                        
                        if (!$foundConnection) {
                            Logger::info("[DEBUG] Could not find connection for resourceId {$resourceId}");
                        }
                    } else {
                        Logger::info("[DEBUG] ResourceId {$resourceId} is NOT subscribed to trade {$tradeId}");
                    }
                }
                
                if ($adminNotificationsSent > 0) {
                    Logger::info("[NOTIFY] Sent trade_closed to {$adminNotificationsSent} subscribed admin(s)");
                } else {
                    Logger::info("[DEBUG] No admins were notified for trade {$tradeId}");
                }
            }
        } catch (Exception $e) {
            error_log("WebSocket::notifyTradeClosed - " . $e->getMessage());
        }
    }
    
    /**
     * Notify user when a pending order is triggered and trade is opened
     * 
     * @param array $order - Pending order data
     * @param array $tradeData - New trade data
     */
    private function notifyOrderTriggered($order, $tradeData) {
        try {
            $userId = $order['userid'];
            $tradeId = $tradeData['trade_id'] ?? null;
            
            // Map order type to user-friendly message
            $orderTypeMessages = [
                'buy_stop' => 'Buy Stop',
                'sell_stop' => 'Sell Stop',
                'buy_limit' => 'Buy Limit',
                'sell_limit' => 'Sell Limit'
            ];
            
            $orderTypeName = $orderTypeMessages[$order['order_type']] ?? $order['order_type'];
            $message = "{$orderTypeName} order triggered for {$order['pair']}";
            
            // Prepare notification message
            $notificationData = [
                'type' => 'trade_opened',
                'trade_id' => $tradeId,
                'ref' => $order['ref'] ?? null,
                'pair' => $order['pair'] ?? null,
                'trade_type' => $order['type'] ?? null,
                'order_type' => $order['order_type'] ?? null,
                'trigger_price' => $order['trigger_price'] ?? null,
                'execution_price' => $tradeData['execution_price'] ?? null,
                'lot' => $order['lot'] ?? null,
                'leverage' => $order['leverage'] ?? null,
                'message' => $message,
                'timestamp' => time(),
                'user_id' => $userId
            ];
            
            // Send notification to the user
            if (isset($this->authenticatedClients[$userId])) {
                Logger::info("[NOTIFY] Sending trade_opened notification to user {$userId} (order_type: {$order['order_type']})");
                
                foreach ($this->authenticatedClients[$userId] as $conn) {
                    $conn->send(json_encode($notificationData));
                }
                
                // Force account update to refresh balance and open trades
                $this->sendAccountUpdate($userId);
            } else {
                Logger::info("[NOTIFY] User {$userId} not connected to WebSocket");
            }
            
        } catch (Exception $e) {
            error_log("WebSocket::notifyOrderTriggered - " . $e->getMessage());
        }
    }
    
    /**
     * Normalize pair format for database lookup
     * Converts: EURUSD -> EUR/USD, BTCUSDT -> BTC/USD, USDJPY -> USD/JPY
     */
    private function normalizePairFormat($pair) {
        // Remove any existing slashes
        $pair = str_replace('/', '', $pair);
        $pair = strtoupper($pair);
        
        // Check if it ends with USDT (crypto pairs)
        if (substr($pair, -4) === 'USDT') {
            // BTCUSDT -> BTC/USD
            return substr($pair, 0, -4) . '/USD';
        }
        
        // For forex and commodity pairs, check database format
        // Try common 6-letter forex pairs (EURUSD -> EUR/USD)
        if (strlen($pair) === 6) {
            return substr($pair, 0, 3) . '/' . substr($pair, 3, 3);
        }
        
        // For commodity pairs with 6 letters (XAUUSD -> XAU/USD)
        if (strlen($pair) === 6 && (substr($pair, 0, 1) === 'X' || substr($pair, 0, 3) === 'WTI' || substr($pair, 0, 5) === 'BRENT')) {
            return substr($pair, 0, 3) . '/' . substr($pair, 3, 3);
        }
        
        // Already has slash or unknown format
        return $pair;
    }
    
    public function updatePrices($prices) {
        // Merge new prices
        $this->currentPrices = array_merge($this->currentPrices, $prices);
        
        // SECURITY: Write live prices to cache with timestamp for trade operations
        // This prevents users from exploiting stale prices
        $livePricesFile = __DIR__ . '/../cache/websocket_live_prices.json';
        $livePricesData = [
            'timestamp' => time(),
            'prices' => $this->currentPrices
        ];
        $result = file_put_contents($livePricesFile, json_encode($livePricesData));
        if ($result === false) {
            error_log("ERROR: Failed to write live prices to cache!");
        }
        
        // ALTER TRADES MONITORING: Process active alter_trades and get altered prices
        // This runs before other monitoring to provide simulated prices
        $alterResult = TradeAlterMonitorService::processAlterTrades($this->currentPrices);
        if ($alterResult['success']) {
            $this->alteredPrices = $alterResult['altered_prices'];
            $this->chartAlters = $alterResult['chart_alters']; // Store chart alters for candle generation
            
            if ($alterResult['deleted_count'] > 0) {
                Logger::info("[ALTER] Processed {$alterResult['deleted_count']} completed alter trades");
            }
            if ($alterResult['closed_trades'] > 0) {
                Logger::info("[ALTER] Closed {$alterResult['closed_trades']} trades that reached target price");
            }
            if (!empty($this->chartAlters)) {
                echo "[ALTER CHART] Active chart alters: " . count($this->chartAlters) . "\n";
                
                // Update forming candles with altered prices (like frontend updateFormingCandle)
                $this->updateFormingCandles($this->chartAlters);
            }
        }
        
        // REAL-TIME MONITORING: Check for stop_loss and take_profit triggers
        // This runs every time prices update from Binance
        $monitorResult = TradeMonitorService::monitorAndCloseTrades($this->currentPrices);
        if ($monitorResult['success'] && $monitorResult['stats']['closed'] > 0) {
            Logger::info("[MONITOR] Auto-closed {$monitorResult['stats']['closed']} trades (SL: {$monitorResult['stats']['stop_loss']}, TP: {$monitorResult['stats']['take_profit']})");
            
            // Note: Notifications are automatically sent via TradeService callback
            // No need to manually notify here
        }
        
        // PENDING ORDERS MONITORING: Check for pending order triggers and expiry
        // This runs every time prices update to check if pending orders should be executed
        $pendingResult = PendingTradeMonitorService::checkPendingOrders($this->currentPrices);
        if ($pendingResult['success']) {
            if ($pendingResult['triggered'] > 0) {
                Logger::info("[PENDING] Triggered {$pendingResult['triggered']} pending orders");
            }
            if ($pendingResult['expired'] > 0) {
                Logger::info("[PENDING] Expired {$pendingResult['expired']} pending orders");
            }
            if (!empty($pendingResult['errors'])) {
                echo "[PENDING] Errors: " . implode(', ', $pendingResult['errors']) . "\n";
            }
        }
        
        // MARGIN CALL MONITORING: Check for margin calls and stop outs
        // Runs less frequently (every 10th price update) to reduce overhead
        static $priceUpdateCount = 0;
        $priceUpdateCount++;
        
        if ($priceUpdateCount % 10 === 0) {
            $marginResult = TradeMonitorService::monitorMarginCalls($this->currentPrices, 50, 20);
            if ($marginResult['success'] && $marginResult['stats']['trades_closed'] > 0) {
                Logger::info("[MARGIN] Margin calls: {$marginResult['stats']['margin_calls']}, Stop outs: {$marginResult['stats']['stop_outs']}, Trades closed: {$marginResult['stats']['trades_closed']}");
                
                // Note: Notifications are automatically sent via TradeService callback
                // No need to manually notify here
            }
        }
        
        // QUEUED NOTIFICATIONS: Process notifications from HTTP processes (admin actions, etc.)
        // Check for queued notifications from HTTP-initiated closures
        $queuedNotifications = WebSocketNotificationQueue::getAndClearQueue();
        if (!empty($queuedNotifications)) {
            echo "[QUEUE] Processing " . count($queuedNotifications) . " queued notifications\n";
            foreach ($queuedNotifications as $notification) {
                if ($notification['type'] === 'trade_closed') {
                    $this->notifyTradeClosed($notification);
                }
            }
        }
        
        // Debug: Count authenticated clients
        $clientCount = 0;
        foreach ($this->authenticatedClients as $userId => $connections) {
            $clientCount += count($connections);
        }
        Logger::info("Broadcasting to {$clientCount} authenticated connections");
        
        // Broadcast price updates to all authenticated clients
        foreach ($this->authenticatedClients as $userId => $connections) {
            foreach ($connections as $conn) {
                // Skip price alteration for admin/superadmin roles
                $userRole = $conn->userRole ?? 'user';
                $skipAlter = in_array($userRole, ['admin', 'superadmin']);
                
                if (isset($conn->subscribedPairs) && is_array($conn->subscribedPairs)) {
                    echo "User {$userId} has subscribed pairs: " . json_encode($conn->subscribedPairs) . "\n";
                    
                    // Get user's account info once for all price checks
                    $accountType = null;
                    $accountId = null;
                    
                    if (!$skipAlter && !empty($this->chartAlters)) {
                        try {
                            $dbConn = Database::getConnection();
                            $stmt = $dbConn->prepare("
                                SELECT a.id_hash, a.type as acc_type 
                                FROM accounts a
                                JOIN users u ON a.id_hash = u.current_account
                                WHERE u.id = ?
                            ");
                            $stmt->bind_param("i", $userId);
                            $stmt->execute();
                            $result = $stmt->get_result();
                            
                            if ($result->num_rows > 0) {
                                $accountInfo = $result->fetch_assoc();
                                $accountType = $accountInfo['acc_type'];
                                $accountId = $accountInfo['id_hash'];
                            }
                        } catch (Exception $e) {
                            error_log("Error getting account info for price alter: " . $e->getMessage());
                        }
                    }
                    
                    // Send price updates for subscribed pairs
                    foreach ($prices as $symbol => $price) {
                        // Check if this symbol matches any subscribed pair
                        $shouldSend = false;
                        $matchedPair = null;
                        
                        foreach ($conn->subscribedPairs as $subscribedPair) {
                            // Simple case-insensitive comparison
                            // Remove slashes and compare (e.g., BTC/USDT, BTCUSDT, btcusdt all match)
                            $normalizedSymbol = strtolower(str_replace('/', '', $symbol));
                            $normalizedPair = strtolower(str_replace('/', '', $subscribedPair));
                            
                            if ($normalizedSymbol === $normalizedPair) {
                                $shouldSend = true;
                                $matchedPair = $subscribedPair; // Store the original pair format
                                break;
                            }
                        }
                        
                        if ($shouldSend) {
                            // Convert matched pair to database format (add slashes)
                            // EURUSD -> EUR/USD, BTCUSDT -> BTC/USD
                            $pairFormat = $this->normalizePairFormat($matchedPair);
                            
                            // DEBUG: Log the pair format and price
                            Logger::info("[DEBUG] Symbol: {$symbol}, PairFormat: {$pairFormat}, Price: {$price}");
                            
                            // Check if there's an altered price for this user on this pair
                            $finalPrice = $price;
                            $isAltered = false;
                            
                            if (!$skipAlter && $accountType !== null && !empty($this->chartAlters)) {
                                // Check for account_pair alter first (most specific)
                                foreach ($this->chartAlters as $alter) {
                                    if ($alter['mode'] === 'account_pair' && 
                                        $alter['account'] === $accountId && 
                                        $alter['pair'] === $pairFormat) {
                                        $finalPrice = $alter['current_price'];
                                        $isAltered = true;
                                        Logger::info("[PRICE ALTER] User {$userId}: {$pairFormat} altered to {$finalPrice} (account_pair mode)");
                                        break;
                                    }
                                }
                                
                                // Check for pair alter (broader scope)
                                if (!$isAltered) {
                                    foreach ($this->chartAlters as $alter) {
                                        if ($alter['mode'] === 'pair' && 
                                            $alter['acc_type'] === $accountType && 
                                            $alter['pair'] === $pairFormat) {
                                            $finalPrice = $alter['current_price'];
                                            $isAltered = true;
                                            Logger::info("[PRICE ALTER] User {$userId}: {$pairFormat} altered to {$finalPrice} (pair mode, acc_type={$accountType})");
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            if (!$isAltered) {
                                Logger::info("Sending price update to user {$userId}: {$symbol} = {$price}");
                            }
                            
                            // Format price as STRING with correct decimals based on pair configuration
                            // Must use string to preserve trailing zeros (e.g., "1.17095" not 1.17)
                            $formattedPrice = PriceFormatterService::formatPriceString($pairFormat, $finalPrice);
                            
                            // DEBUG: Log formatted price
                            Logger::info("[DEBUG] Formatted price for {$pairFormat}: '{$formattedPrice}'");
                            
                            $conn->send(json_encode([
                                'type' => 'price_update',
                                'symbol' => strtoupper($symbol),
                                'price' => $formattedPrice,
                                'is_altered' => $isAltered,
                                'timestamp' => time()
                            ]));
                        }
                    }
                } else {
                    Logger::info("User {$userId} has no subscribedPairs set");
                }
            }
            
            // Send account update once per user (not per connection)
            $this->sendAccountUpdate($userId);
        }
        
        // Broadcast admin account subscriptions
        foreach ($this->adminAccountSubscriptions as $resourceId => $accountIds) {
            foreach ($accountIds as $accountId) {
                $this->sendAdminAccountUpdate($accountId);
            }
        }
        
        // Broadcast admin trade subscriptions
        foreach ($this->adminTradeSubscriptions as $resourceId => $tradeIds) {
            foreach ($tradeIds as $tradeId) {
                $this->sendAdminTradeUpdate($tradeId);
            }
        }
    }
    
    /**
     * Update forming candles with current altered prices
     * Mimics frontend updateFormingCandle() - tracks high/low over the candle period
     */
    public function updateFormingCandles($chartAlters) {
        $currentTime = time() * 1000; // Convert to milliseconds
        
        foreach ($chartAlters as $alter) {
            $price = $alter['current_price'];
            $pair = $alter['pair'];
            $mode = $alter['mode'];
            $accType = $alter['acc_type'] ?? null;
            $account = $alter['account'] ?? null;
            
            // Create unique key for this forming candle
            if ($mode === 'pair') {
                $candleKey = "pair_{$pair}_{$accType}";
            } elseif ($mode === 'account_pair') {
                $candleKey = "account_{$account}_{$pair}";
            } else {
                continue; // Skip 'trade' mode
            }
            
            // Initialize forming candle if it doesn't exist
            if (!isset($this->formingCandles[$candleKey])) {
                $this->formingCandles[$candleKey] = [
                    'open' => $price,
                    'high' => $price,
                    'low' => $price,
                    'close' => $price,
                    'volume' => 0,
                    'start_time' => $currentTime,
                    'pair' => $pair,
                    'mode' => $mode,
                    'acc_type' => $accType,
                    'account' => $account
                ];
                Logger::info("[FORMING CANDLE] Initialized: {$candleKey} at price {$price}");
            } else {
                // Update existing forming candle (like frontend updateFormingCandle)
                $this->formingCandles[$candleKey]['close'] = $price;
                $this->formingCandles[$candleKey]['high'] = max($this->formingCandles[$candleKey]['high'], $price);
                $this->formingCandles[$candleKey]['low'] = min($this->formingCandles[$candleKey]['low'], $price);
                
                // Log significant updates
                $oldRange = $this->formingCandles[$candleKey]['high'] - $this->formingCandles[$candleKey]['low'];
                if ($oldRange > 0) {
                    Logger::info("[FORMING CANDLE] Updated: {$candleKey} - O:{$this->formingCandles[$candleKey]['open']} H:{$this->formingCandles[$candleKey]['high']} L:{$this->formingCandles[$candleKey]['low']} C:{$price}");
                }
            }
        }
    }
    
    public function broadcastCandle($candle) {
        $pair = $candle['pair'];
        $interval = $candle['interval'];
        
        Logger::info("\n=== BROADCAST CANDLE START ===");
        Logger::info("[BROADCAST] Pair: {$pair}, Interval: {$interval}");
        echo "[BROADCAST] Chart alters count: " . count($this->chartAlters) . "\n";
        
        if (!empty($this->chartAlters)) {
            Logger::info("[BROADCAST] Active chart alters:");
            foreach ($this->chartAlters as $idx => $alter) {
                echo "[BROADCAST]   #{$idx}: mode={$alter['mode']}, pair={$alter['pair']}, acc_type={$alter['acc_type']}, progress=" . round($alter['progress'] * 100, 2) . "%\n";
            }
        }
        
        $sentCount = 0;
        $alteredCount = 0;
        
        // Check if there are any active chart alters for this pair
        $hasChartAlters = !empty($this->chartAlters);
        
        // Track which alter cache files we've already saved for this candle (to avoid duplicates)
        $savedCaches = [];
        
        if ($hasChartAlters) {
            Logger::info("[BROADCAST] Checking chart alters for {$pair} {$interval}...");
        }
        
        // Broadcast to all clients subscribed to this pair's chart
        foreach ($this->clients as $conn) {
            $resourceId = $conn->resourceId;
            
            Logger::info("[BROADCAST] Checking client {$resourceId}...");
            
            // Check if this client has chart subscriptions
            if (!isset($this->chartSubscriptions[$resourceId])) {
                Logger::info("[BROADCAST]   Client {$resourceId} has no chart subscriptions");
                continue;
            }
            
            $clientSubs = $this->chartSubscriptions[$resourceId];
            echo "[BROADCAST]   Client {$resourceId} subscriptions: " . json_encode($clientSubs) . "\n";
            
            // Check if subscribed to this pair and interval
            if (isset($clientSubs[$pair]) && $clientSubs[$pair] === $interval) {
                Logger::info("[BROADCAST]   ✓ Client {$resourceId} is subscribed to {$pair} {$interval}");
                
                // Determine if we should send altered candle for this specific client
                $candleToSend = $candle;
                $userId = $conn->userId ?? null;
                
                if ($hasChartAlters && $userId !== null) {
                    // Get user's current account info to determine account type and account ID
                    try {
                        $dbConn = Database::getConnection();
                        $stmt = $dbConn->prepare("
                            SELECT a.id_hash, a.type as acc_type 
                            FROM accounts a
                            JOIN users u ON a.id_hash = u.current_account
                            WHERE u.id = ?
                        ");
                        $stmt->bind_param("i", $userId);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        
                        if ($result->num_rows > 0) {
                            $accountInfo = $result->fetch_assoc();
                            $accountType = $accountInfo['acc_type']; // 'demo' or 'real'
                            $accountId = $accountInfo['id_hash'];
                            
                            Logger::info("[BROADCAST]   User {$userId} account: type={$accountType}, id={$accountId}");
                            
                            // Check if this candle should be altered for this client
                            $alterInfo = TradeAlterMonitorService::shouldAlterCandle(
                                $this->chartAlters,
                                $pair,
                                $userId,
                                $accountType,
                                $accountId
                            );
                            
                            if ($alterInfo !== null) {
                                // Get the forming candle key for this alter
                                $formingKey = null;
                                if ($alterInfo['mode'] === 'pair') {
                                    $formingKey = "pair_{$pair}_{$accountType}";
                                } elseif ($alterInfo['mode'] === 'account_pair') {
                                    $formingKey = "account_{$accountId}_{$pair}";
                                }
                                
                                // Use tracked forming candle OHLC if available, otherwise generate synthetic
                                if ($formingKey && isset($this->formingCandles[$formingKey])) {
                                    $formingCandle = $this->formingCandles[$formingKey];
                                    
                                    // Create altered candle with tracked OHLC
                                    $candleToSend = array_merge($candle, [
                                        'open' => $formingCandle['open'],
                                        'high' => $formingCandle['high'],
                                        'low' => $formingCandle['low'],
                                        'close' => $formingCandle['close'],
                                        'is_altered' => true
                                    ]);
                                    
                                    Logger::info("[BROADCAST] Using TRACKED forming candle for {$formingKey}: O:{$formingCandle['open']} H:{$formingCandle['high']} L:{$formingCandle['low']} C:{$formingCandle['close']}");
                                    
                                    // Reset forming candle for next period
                                    unset($this->formingCandles[$formingKey]);
                                } else {
                                    // Fallback: Generate synthetic candle (backward compatibility)
                                    $candleToSend = TradeAlterMonitorService::createAlteredCandle(
                                        $candle,
                                        $alterInfo,
                                        null // previousClose
                                    );
                                    Logger::info("[BROADCAST] Using SYNTHETIC candle (no forming candle tracked)");
                                }
                                
                                $alteredCount++;
                                Logger::info("[BROADCAST] Sending ALTERED candle to user {$userId} (account: {$accountType})");
                                
                                // Save altered candle to cache (once per mode+pair+account combination)
                                // Create unique cache key to prevent duplicate saves
                                $cacheKey = $alterInfo['mode'] . '_' . $pair . '_' . $interval;
                                if ($alterInfo['mode'] === 'pair') {
                                    $cacheKey .= '_' . $accountType;
                                } elseif ($alterInfo['mode'] === 'account_pair') {
                                    $cacheKey .= '_' . $accountId;
                                }
                                
                                // Only save once per candle per cache type
                                if (!isset($savedCaches[$cacheKey])) {
                                    $saved = AlteredCandleCacheService::saveAlteredCandle(
                                        $candleToSend,
                                        $alterInfo['mode'],
                                        $pair,
                                        $interval,
                                        $accountType,
                                        $accountId
                                    );
                                    
                                    if ($saved) {
                                        $savedCaches[$cacheKey] = true;
                                        Logger::info("[BROADCAST] ✓ Saved altered candle to cache: {$cacheKey}");
                                    }
                                }
                            }
                        } else {
                            Logger::info("[BROADCAST]   ⚠ User {$userId} has no current account!");
                        }
                    } catch (Exception $e) {
                        error_log("Error checking chart alter for user {$userId}: " . $e->getMessage());
                        echo "[BROADCAST]   ❌ Error: " . $e->getMessage() . "\n";
                        // Fallback to real candle on error
                    }
                }
                
                // Send candle (real or altered based on above logic)
                // Format candle prices with correct decimals before sending
                $formattedCandle = PriceFormatterService::formatCandle($pair, $candleToSend);
                $jsonData = json_encode($formattedCandle);
                $conn->send($jsonData);
                $sentCount++;
                
                if (!isset($alterInfo) || $alterInfo === null) {
                    Logger::info("[BROADCAST] Sent REAL candle to client {$resourceId}");
                }
            }
        }
        
        if ($sentCount > 0) {
            $alteredMsg = $alteredCount > 0 ? " ({$alteredCount} altered)" : "";
            Logger::info("Broadcast {$pair} {$interval} candle to {$sentCount} client(s){$alteredMsg}");
        } else {
            Logger::info("[BROADCAST] No clients subscribed to {$pair} {$interval}");
        }
        Logger::info("=== BROADCAST CANDLE END ===\n");
    }
    
    /**
     * Broadcast market status to all connected clients
     * 
     * @param array $marketData - Market status data for both forex and stocks
     */
    public function broadcastMarketStatus($marketData) {
        // Store full market data for later use
        $this->currentMarketData = $marketData;
        
        // Store current status (use forex status as primary for backward compatibility)
        $this->currentMarketStatus = is_array($marketData) ? ($marketData['forex']['status'] ?? 'unknown') : $marketData;
        
        // Handle both old format (string) and new format (array)
        if (!is_array($marketData)) {
            // Old format - convert to new format for forex only
            $status = $marketData;
            $nextOpen = ($status === 'closed') ? FinnhubWebSocketClient::getNextOpenTimestamp() : null;
            $remaining = $nextOpen ? ($nextOpen - time()) : null;
            
            $message = [
                'type' => 'market_status',
                'status' => $status,
                'timestamp' => time(),
                'next_open' => $nextOpen,
                'remaining' => $remaining,
                'message' => $status === 'closed' 
                    ? 'Forex and commodity markets are currently closed' 
                    : 'Forex and commodity markets are now open',
                'affects' => 'forex_commodities'
            ];
        } else {
            // New format - include both forex and stock market data
            $message = [
                'type' => 'market_status',
                'timestamp' => time(),
                'markets' => $marketData,
                'message' => $this->generateMarketStatusMessage($marketData)
            ];
        }
        
        $jsonMessage = json_encode($message);
        $sentCount = 0;
        
        // Send to all connected clients
        foreach ($this->clients as $conn) {
            try {
                $conn->send($jsonMessage);
                $sentCount++;
            } catch (Exception $e) {
                error_log("Error broadcasting market status to client: " . $e->getMessage());
            }
        }
        
        Logger::info("[MARKET] Broadcasted market status to {$sentCount} client(s)");
    }
    
    /**
     * Generate human-readable market status message
     * 
     * @param array $marketData - Market data for forex and stocks
     * @return string - Status message
     */
    private function generateMarketStatusMessage($marketData) {
        $forexStatus = $marketData['forex']['status'] ?? 'unknown';
        $stockStatus = $marketData['stocks']['status'] ?? 'unknown';
        
        if ($forexStatus === 'open' && $stockStatus === 'open') {
            return 'All markets are currently open';
        } elseif ($forexStatus === 'closed' && $stockStatus === 'closed') {
            return 'All markets are currently closed';
        } elseif ($forexStatus === 'open') {
            return 'Forex & Commodity markets are open. Stock markets are closed.';
        } else {
            return 'Stock markets are open. Forex & Commodity markets are closed.';
        }
    }
    
    /**
     * Send current market status to a specific client (e.g., newly connected)
     * 
     * @param ConnectionInterface $conn - Client connection
     */
    private function sendCurrentMarketStatus(ConnectionInterface $conn) {
        // Use stored market data if available (new format)
        if ($this->currentMarketData !== null && is_array($this->currentMarketData)) {
            $message = [
                'type' => 'market_status',
                'timestamp' => time(),
                'markets' => $this->currentMarketData,
                'message' => $this->generateMarketStatusMessage($this->currentMarketData)
            ];
            
            try {
                $conn->send(json_encode($message));
                Logger::info("[MARKET] Sent market status (new format) to client {$conn->resourceId}");
            } catch (Exception $e) {
                error_log("Error sending market status to client: " . $e->getMessage());
            }
            return;
        }
        
        // Fallback to old format if market data not yet available
        $status = $this->currentMarketStatus;
        
        if ($status === 'unknown') {
            // Assume open by default for better UX
            // The real status will be broadcast once determined
            $status = 'open';
            Logger::info("[MARKET] Status still unknown, sending default 'open' to client {$conn->resourceId}");
        }
        
        $nextOpen = ($status === 'closed') ? FinnhubWebSocketClient::getNextOpenTimestamp() : null;
        $remaining = $nextOpen ? ($nextOpen - time()) : null;
        
        $message = [
            'type' => 'market_status',
            'status' => $status,
            'timestamp' => time(),
            'next_open' => $nextOpen,
            'remaining' => $remaining,
            'message' => $status === 'closed' 
                ? 'Forex and commodity markets are currently closed' 
                : 'Forex and commodity markets are now open',
            'affects' => 'forex_commodities'
        ];
        
        try {
            $conn->send(json_encode($message));
            Logger::info("[MARKET] Sent market status (old format fallback) '{$status}' to client {$conn->resourceId}");
        } catch (Exception $e) {
            error_log("Error sending market status to client: " . $e->getMessage());
        }
    }
}

// Binance WebSocket Client using ReactPHP
class BinanceWebSocketClient {
    private $server;
    private $pairs;
    private $loop;
    private $wsConnection;
    private $klineConnection;
    private $retryCount = 0;
    private $maxRetries = 10; // Max retry attempts before giving up
    private $reconnectTimer = null;
    
    public function __construct($server, $pairs, $loop) {
        $this->server = $server;
        $this->pairs = $pairs;
        $this->loop = $loop;
    }
    
    public function connect() {
        Logger::info("Connecting to Binance WebSocket...");
        
        // Build WebSocket stream URL for multiple pairs (ticker data)
        $streams = [];
        foreach ($this->pairs as $pair) {
            $symbol = strtolower(str_replace(['/', 'USD'], ['', 'USDT'], $pair));
            $streams[] = $symbol . '@ticker';
        }
        $streamString = implode('/', $streams);
        
        // Use port 443 instead of 9443 (some firewalls block 9443)
        $wsUrl = "wss://stream.binance.com:443/stream?streams=" . $streamString;
        
        // Use Google's public DNS (8.8.8.8) instead of React's default DNS
        $dnsResolverFactory = new \React\Dns\Resolver\Factory();
        $dns = $dnsResolverFactory->createCached('8.8.8.8', $this->loop);
        
        $connector = new WsConnector($this->loop, new Connector($this->loop, ['dns' => $dns]));
        
        $connector($wsUrl)->then(
            function($conn) {
                Logger::info("Connected to Binance Ticker WebSocket!");
                $this->wsConnection = $conn;
                
                $conn->on('message', function($msg) {
                    $this->handleBinanceMessage($msg);
                });
                
                $conn->on('close', function($code = null, $reason = null) {
                    Logger::info("Binance WebSocket closed (Code: {$code}, Reason: {$reason})");
                    $this->wsConnection = null; // Clear reference
                    $this->scheduleReconnect('ticker');
                });
                
                $conn->on('error', function($e) {
                    Logger::info("Binance WebSocket error: {$e->getMessage()}");
                });
            },
            function($e) {
                Logger::info("Could not connect to Binance: {$e->getMessage()}");
                $this->scheduleReconnect('ticker');
            }
        );
    }
    
    private function scheduleReconnect($type = 'ticker') {
        // Limit retry attempts to prevent infinite loops
        if ($this->retryCount >= $this->maxRetries) {
            Logger::info("[ERROR] Max retry attempts ({$this->maxRetries}) reached for Binance {$type}. Stopping reconnection.");
            return;
        }
        
        $this->retryCount++;
        
        // Exponential backoff: 5s, 10s, 20s, 40s... (max 60s)
        $delay = min(5 * pow(2, $this->retryCount - 1), 60);
        
        Logger::info("Retrying Binance {$type} in {$delay}s (attempt {$this->retryCount}/{$this->maxRetries})...");
        
        // Cancel any existing reconnect timer to prevent accumulation
        if ($this->reconnectTimer) {
            $this->loop->cancelTimer($this->reconnectTimer);
        }
        
        $this->reconnectTimer = $this->loop->addTimer($delay, function() use ($type) {
            if ($type === 'kline') {
                $this->connectKlineStreams();
            } else {
                $this->connect();
            }
        });
        
        // Connect to kline streams for chart data (1m, 5m intervals)
        $this->connectKlineStreams();
    }
    
    private function connectKlineStreams() {
        Logger::info("Connecting to Binance Kline WebSocket...");
        
        // Build kline streams for common intervals
        $intervals = ['1m', '5m', '15m', '1h', '4h', '1d'];
        $klineStreams = [];
        foreach ($this->pairs as $pair) {
            $symbol = strtolower(str_replace(['/', 'USD'], ['', 'USDT'], $pair));
            foreach ($intervals as $interval) {
                $klineStreams[] = $symbol . '@kline_' . $interval;
            }
        }
        
        $streamString = implode('/', $klineStreams);
        // Use port 443 instead of 9443 (some firewalls block 9443)
        $wsUrl = "wss://stream.binance.com:443/stream?streams=" . $streamString;
        
        $dnsResolverFactory = new \React\Dns\Resolver\Factory();
        $dns = $dnsResolverFactory->createCached('8.8.8.8', $this->loop);
        
        $connector = new WsConnector($this->loop, new Connector($this->loop, ['dns' => $dns]));
        
        $connector($wsUrl)->then(
            function($conn) {
                Logger::info("Connected to Binance Kline WebSocket!");
                $this->klineConnection = $conn;
                
                $conn->on('message', function($msg) {
                    $this->handleKlineMessage($msg);
                });
                
                $conn->on('close', function($code = null, $reason = null) {
                    Logger::info("Binance Kline WebSocket closed (Code: {$code}, Reason: {$reason})");
                    $this->klineConnection = null; // Clear reference
                    $this->scheduleReconnect('kline');
                });
                
                $conn->on('error', function($e) {
                    Logger::info("Binance Kline WebSocket error: {$e->getMessage()}");
                });
            },
            function($e) {
                Logger::info("Could not connect to Binance Kline stream: {$e->getMessage()}");
                $this->scheduleReconnect('kline');
            }
        );
    }
    
    private function handleBinanceMessage($msg) {
        try {
            $data = json_decode($msg, true);
            
            if (isset($data['stream']) && isset($data['data'])) {
                $tickerData = $data['data'];
                
                // Extract symbol and price
                if (isset($tickerData['s']) && isset($tickerData['c'])) {
                    $symbol = strtolower($tickerData['s']);
                    $price = floatval($tickerData['c']);
                    
                    // Debug: Log received price
                    Logger::info("Binance price update: {$symbol} = {$price}");
                    
                    // Update prices
                    $this->server->updatePrices([$symbol => $price]);
                }
            } else {
                // Debug: Log unexpected message format
                echo "Binance message without stream/data: " . substr($msg, 0, 100) . "\n";
            }
        } catch (Exception $e) {
            error_log("Error processing Binance message: " . $e->getMessage());
            echo "Error processing Binance message: " . $e->getMessage() . "\n";
        }
    }
    
    private function handleKlineMessage($msg) {
        try {
            $data = json_decode($msg, true);
            
            if (isset($data['stream']) && isset($data['data'])) {
                $klineData = $data['data'];
                
                // Kline data structure:
                // {
                //   "e": "kline",
                //   "E": 123456789,
                //   "s": "BTCUSDT",
                //   "k": {
                //     "t": 123400000, // Kline start time
                //     "T": 123460000, // Kline close time
                //     "s": "BTCUSDT",
                //     "i": "1m",      // Interval
                //     "f": 100,       // First trade ID
                //     "L": 200,       // Last trade ID
                //     "o": "0.0010",  // Open price
                //     "c": "0.0020",  // Close price
                //     "h": "0.0025",  // High price
                //     "l": "0.0015",  // Low price
                //     "v": "1000",    // Base asset volume
                //     "n": 100,       // Number of trades
                //     "x": false,     // Is this kline closed?
                //     "q": "1.0000",  // Quote asset volume
                //     "V": "500",     // Taker buy base asset volume
                //     "Q": "0.500",   // Taker buy quote asset volume
                //     "B": "123456"   // Ignore
                //   }
                // }
                
                if (isset($klineData['k'])) {
                    $k = $klineData['k'];
                    $symbol = strtolower($k['s']);
                    $interval = $k['i'];
                    
                    // Convert to our pair format (btcusdt -> BTC/USD)
                    $pair = strtoupper(str_replace('usdt', '/USD', $symbol));
                    
                    $candle = [
                        'type' => 'candle_update',
                        'pair' => $pair,
                        'symbol' => $symbol,
                        'interval' => $interval,
                        'timestamp' => intval($k['t']),
                        'time' => date('Y-m-d H:i:s', intval($k['t']) / 1000),
                        'open' => floatval($k['o']),
                        'high' => floatval($k['h']),
                        'low' => floatval($k['l']),
                        'close' => floatval($k['c']),
                        'volume' => floatval($k['v']),
                        'trades' => intval($k['n']),
                        'isClosed' => $k['x']
                    ];
                    
                    // Only send closed candles to reduce noise
                    if ($k['x'] === true) {
                        Logger::info("Kline closed: {$pair} {$interval} - O:{$k['o']} H:{$k['h']} L:{$k['l']} C:{$k['c']}");
                        $this->server->broadcastCandle($candle);
                    }
                }
            }
        } catch (Exception $e) {
            error_log("Error processing Binance kline message: " . $e->getMessage());
            echo "Error processing Binance kline message: " . $e->getMessage() . "\n";
        }
    }
    
    public function close() {
        // Cancel any pending reconnect timers
        if ($this->reconnectTimer) {
            $this->loop->cancelTimer($this->reconnectTimer);
            $this->reconnectTimer = null;
        }
        
        // Close connections
        if ($this->wsConnection) {
            $this->wsConnection->close();
            $this->wsConnection = null;
        }
        if ($this->klineConnection) {
            $this->klineConnection->close();
            $this->klineConnection = null;
        }
        
        Logger::info("Binance WebSocket connections closed");
    }
}

// Start server
if (php_sapi_name() === 'cli') {
    $port = 8080;
    
    Logger::info("Starting Trading WebSocket Server on port {$port}...");
    
    // Create PID file
    $pidFile = __DIR__ . '/server.pid';
    $pidData = [
        'pid' => getmypid(),
        'started_at' => time()
    ];
    file_put_contents($pidFile, json_encode($pidData));
    
    // Get active pairs from database
    $conn = Database::getConnection();
    $result = $conn->query("SELECT name, type FROM pairs WHERE status = 'active'");
    $pairs = [];
    $cryptoPairs = [];
    $forexCommodityPairs = [];
    
    while ($row = $result->fetch_assoc()) {
        $pairs[] = $row['name'];
        
        // Separate pairs by type for different data sources
        if ($row['type'] === 'crypto') {
            $cryptoPairs[] = $row['name'];
        } elseif (in_array($row['type'], ['forex', 'commodity', 'stock', 'index'])) {
            // All non-crypto pairs use Finnhub (forex, commodities, stocks, indices)
            $forexCommodityPairs[] = $row['name'];
        }
    }
    
    Logger::info("Monitoring " . count($pairs) . " pairs total");
    Logger::info("- Crypto pairs (Binance): " . count($cryptoPairs));
    Logger::info("- Non-crypto pairs (Finnhub - forex/commodities/stocks/indices): " . count($forexCommodityPairs));
    
    // Preload pair configurations for formatting (includes price_decimals, volume_decimals)
    Logger::info("Loading pair configurations for price formatting...");
    PriceFormatterService::preloadPairConfigs();
    
    // Create ReactPHP event loop
    $loop = LoopFactory::create();
    
    // Create WebSocket server
    $tradingServer = new TradingWebSocketServer();
    
    // Create socket server
    $webSock = new React\Socket\Server("0.0.0.0:{$port}", $loop);
    $webServer = new IoServer(
        new HttpServer(
            new WsServer($tradingServer)
        ),
        $webSock,
        $loop
    );
    
    // Start Binance WebSocket client for crypto pairs
    if (!empty($cryptoPairs)) {
        $binanceClient = new BinanceWebSocketClient($tradingServer, $cryptoPairs, $loop);
        $binanceClient->connect();
    }
    
    // Start Finnhub WebSocket client for forex and commodity pairs
    if (!empty($forexCommodityPairs)) {
        $keys = require __DIR__ . '/../config/keys.php';
        $finnhubApiKey = $keys['finnhub']['api_key'] ?? '';
        
        $finnhubClient = new FinnhubWebSocketClient($tradingServer, $forexCommodityPairs, $loop, $finnhubApiKey);
        $finnhubClient->connect();
    }
    
    // Add periodic timer to check for stop signal and send account updates (every 2 seconds)
    $stopFile = __DIR__ . '/server.stop';
    
    // Log the stop file path once for debugging
    Logger::info("Monitoring for stop signal at: {$stopFile}");
    
    // Check if stop file exists at startup (shouldn't exist)
    if (file_exists($stopFile)) {
        Logger::info("WARNING: Stop file exists at startup! Removing it: {$stopFile}");
        @unlink($stopFile);
    }
    
    $loop->addPeriodicTimer(2, function() use ($tradingServer, $stopFile, $loop) {
        // Check for stop signal file (graceful shutdown for cPanel)
        $stopExists = file_exists($stopFile);
        
        if ($stopExists) {
            Logger::info("\nStop signal received. Shutting down gracefully...");
            Logger::info("Stop file found at: {$stopFile}");
            @unlink($stopFile);
            
            $pidFile = __DIR__ . '/server.pid';
            if (file_exists($pidFile)) {
                @unlink($pidFile);
            }
            
            $loop->stop();
            exit(0);
        }
        
        // Account updates are already sent in updatePrices, 
        // but this ensures updates even if no price changes
    });
    
    // Clean old altered candle caches once per day (86400 seconds)
    $loop->addPeriodicTimer(86400, function() {
        Logger::info("\n[CACHE CLEANUP] Running daily cache cleanup...");
        $stats = AlteredCandleCacheService::cleanOldCaches(30); // Keep 30 days
        echo "[CACHE CLEANUP] Completed: " . json_encode($stats) . "\n";
    });
    
    Logger::info("Server running!");
    Logger::info("Clients can connect to: ws://localhost:{$port}");
    if (!empty($cryptoPairs)) {
        Logger::info("Binance WebSocket connected and streaming crypto prices...");
    }
    if (!empty($forexCommodityPairs)) {
        Logger::info("Finnhub WebSocket connected and streaming forex/commodity prices...");
    }
    
    // Register shutdown handler to clean up PID file
    register_shutdown_function(function() use ($pidFile) {
        if (file_exists($pidFile)) {
            @unlink($pidFile);
            Logger::info("\nShutdown complete. PID file removed.");
        }
    });
    
    // Run the event loop
    $loop->run();
}
